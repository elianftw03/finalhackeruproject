import { useEffect, useState } from "react";
import axios from "../api/axiosInstance";
import PetCard from "../components/PetCard";
import "../styles/PetList.css";
import "../styles/EmptyState.css";

function PetList() {
  const [pets, setPets] = useState([]);

  useEffect(() => {
    const run = async () => {
      const res = await axios.get("/pets");
      setPets(res.data);
    };
    run();
  }, []);

  return (
    <div className="container section">
      <h2>Available Pets</h2>
      {pets.length === 0 ? (
        <div className="empty">
          <div className="empty-card">
            <h3>No pets found</h3>
            <p>Try a different category or come back later.</p>
          </div>
        </div>
      ) : (
        <div className="grid-cards">
          {pets.map((pet) => (
            <PetCard key={pet._id} pet={pet} />
          ))}
        </div>
      )}
    </div>
  );
}

export default PetList;
